####Choice of active covariate####### 
#@Ymat: n*m response on a grid
#@X: n*p1 covariates to adjust for, p1=2 is fixed here, change accordingly otherwise 
#@M: n*p2 covariates for single index
act.cov.index<-function(Ymat,X,M)
{Ymean<-rowMeans(Ymat)
  res.act.cov<-function(j)
{initfit<-gam(Ymean~X[,1]+X[,2]+s(M[,j],k=3))#we don't want to overfit
mean((initfit$residuals^2))}
resvec<-unlist(lapply(1:ncol(M),res.act.cov))
which.min(resvec)
}

####Choice of initial alpha####### 
#@Ymat: n*m response on a grid
#@X: n*p1 covariates to adjust for 
#@M: n*p2 covariates for single index
#@try: number of initial values to be tried
Initial.alpha.choose<-function(Ymat,X,M,try=10)
{Ymean<-rowMeans(Ymat)  
si <- function(theta,y,x,z1,z2,opt=TRUE,k=10,fx=FALSE) {
  alpha <- c(1,theta) ## constrained alpha defined using free theta
  kk <- sqrt(sum(alpha^2))
  alpha <- alpha/kk  ## so now ||alpha||=1
  a <- x%*%alpha     ## argument of smooth
  b <- gam(y~s(a,fx=fx,k=k)+s(z1)+s(z2),family=gaussian,method="ML") ## fit model
  if (opt) return(b$gcv.ubre) else {
    b$alpha <- alpha  
    J <- outer(alpha,-theta/kk^2) 
    for (j in 1:length(theta)) J[j+1,j] <- J[j+1,j] + 1/kk
    b$J <- J 
    return(b)
  }
}

## simulate some data from a single index model...
th0mat<-matrix(0,try,(p2-1))
theta.estmat<-matrix(0,try,(p2-1))

th0mat[1,] <-rep(0,(p2-1))
th0mat[2:try,]<-matrix(c(rnorm((p2-1)*(try-1))),(try-1),(p2-1))
minval<-c()
for(k in 1:nrow(theta.estmat))
{
  th0 <- th0mat[k,]
  ###nlm slower but better
  ## get initial theta, using no penalization...
  f0 <- nlm(si,th0,y=Ymean,x=M,z1=X[,1],z2=X[,2],fx=TRUE,k=5)
  ## now get theta/alpha with smoothing parameter selection...
  f1 <- nlm(si,f0$estimate,y=Ymean,x=M,z1=X[,1],z2=X[,2],hessian=TRUE,k=10)
  theta.estmat[k,] <-f1$estimate 
  minval[k]<-f1$minimum
}
indmin<-which.min(minval)
alpha_in<-c(1,theta.estmat[indmin,])
alpha_in<-(alpha_in)/(sqrt(sum((alpha_in)^2)))
alpha_in
}


####Variable selection for fixed lambda####### 
#@Ymat: n*m response on a grid
#@X: n*p1 covariates to adjust for 
#@M: n*p2 covariates for single index
#@UT: Grid of timepoints for Y(t)
#@alpha_in: Initial value of alpha
#@lambda: Penalty parameter corresponding to MCP on alpha
#@maxit: Maximum iteration for the iterative procedure
#@tol: Relative tolerance limit for covergence

##change based on X (keep p1=2) but make M(p2) flexible
FSIM.varsel<-function(Ymat,X,M,UT,alpha_in,lambda,maxit=50,tol=0.001)
{  
  c0=alpha_in
  c1=alpha_in
  p1=ncol(X)
  p2=ncol(M)
  mu0=rep(0.5,p2)
  mu1=rep(0.5,p2)
  rho=1
  m=length(UT)
  ######################################
  gamma=3
  UGRIDsub<-seq(-8,8,l=100)
  normalize<-function(x){
    if(sum(x^2)==0){x}
    else
    {x/sqrt(sum(x^2))}
  }
  
  bicfunc<-function(lambda){
    n<-nrow(M)
    #lambda<-c(1) #choose lambda by BIC or similar criterion
    #muestL<-list()
    b1estL<-list()
    b2estL<-list()
    param_thetasurfL<-list()
    alphaL<-list()
    c0L<-list()
    c1L<-list()
    mu0L<-list()
    mu1L<-list()
    thetaloss<-list()
    ######################################
    for(iter in 1: maxit)
    {
      U<-as.numeric(M%*%alpha_in) 
      Ugl<-U
      library(fda) 
      knots = seq(min(UT),max(UT),l=10) #12 basis functions
      norder = 4
      # this implies the number of basis functions
      nbasis = length(knots) + norder - 2
      dayrng = c(min(UT),max(UT))
      bbasis = create.bspline.basis(dayrng,nbasis,norder,knots)
      bbasisMat<-list()
      for (i in 1:n)
      {bbasisMat[[i]] = eval.basis(T[[i]],bbasis)}
      basismat<-bbasisMat
      for (i in 1:n){
        colnames(basismat[[i]])<-NULL}
      
      #define xi beta(t) matrix and s(u,t) matrix #########
      XMatstar<-list()
      for(i in 1:n)
      {XMatstar[[i]]<-array(0,dim=c(p1,length(T[[i]]),nbasis))
      for (j in 1:p1){
        for(l in 1:length(T[[i]])){
          Xhat_resp=X[i,j]
          XMatstar[[i]][j,l,]=Xhat_resp*basismat[[i]][l,]
          
        }
      }
      }
      
      
      Zimatlist<-list()
      for (i in 1:n)
      {Zimatlist[[i]]<-matrix(0,length(T[[i]]),nbasis*p1)
      for(l in 1:length(T[[i]]))
      {for(j in 1 :p1){
        Zimatlist[[i]][l,((nbasis*(j-1))+1):(nbasis*j)]<-XMatstar[[i]][j,l,]
      }
      }
      }
      temp<-NULL
      for(i in 1:n)
      {temp<-rbind(temp, Zimatlist[[i]])
      }
      GrandX<-temp
      
      ###define s(u,t) basismat##########
      library(fda)
      knotsT = seq(min(UT),max(UT),l=5) #7 basis in U
      knotsU = seq(min(Ugl)-3,max(Ugl)+3,l=5) #some knots beyond range
      norder = 4
      # this implies the number of basis functions
      nbasisT = length(knotsT) + norder - 2
      nbasisU = length(knotsU) + norder - 2
      dayrngT = c(min(S),max(S))
      dayrngU = c(min(Ugl)-3,max(Ugl)+3)
      bbasisT = create.bspline.basis(dayrngT,nbasisT,norder,knotsT)
      bbasisU = create.bspline.basis(dayrngU,nbasisU,norder,knotsU)
      
      Bmat<-list()
      for (i in 1:n)
      {Bmat[[i]] = eval.basis(T[[i]],bbasisT)}
      for (i in 1:n){
        colnames(Bmat[[i]])<-NULL}
      B<-Bmat
      bbasisMatU<-list()
      for (i in 1:n)
      {temp1= eval.basis(U[i],bbasisU)
      bbasisMatU[[i]] =matrix(as.numeric(temp1),nrow=m,ncol=nbasisU,byrow=TRUE) }
      
      
      SMatstar<-list()
      for(i in 1:n)
      {
        SMatstar[[i]]<-matrix(0,length(T[[i]]),(nbasisT)*(nbasisU))
        for(k in 1:length(T[[i]]))
        {SMatstar[[i]][k,]<-bbasisMatU[[i]][k,]%x%B[[i]][k,]}
      }
      
      temp3<-NULL
      for(i in 1:n)
      {temp3<-rbind(temp3, SMatstar[[i]])
      }
      GrandS<-temp3
      
      #library(mgcv)
      #modfit<-bam(GrandY~ -1+GrandB+GrandX+GrandS)
      GrandZZ<-cbind(GrandX,GrandS)
      group<-c(rep(1,nbasis),rep(2,nbasis),rep(3,ncol(GrandS)))
      library(grpreg)
      Groupvar<-as.factor(group)
      fit3 <- grpreg(GrandZZ,GrandY,Groupvar,penalty="grMCP")
      cvfit3<-select(fit3,crit="EBIC")
      gamma3<-cvfit3$beta
      st<-(0*nbasis)+1
      end<- 1*nbasis 
      b1coef<-gamma3[-1][st:end]   
      b1_est<-function(t)
      {basisvec<-eval.basis(t,bbasis)
      val<-crossprod(t(basisvec),b1coef)
      as.numeric(val)
      }
      b1vec<-b1_est(S)
      b1estL[[iter]]<-b1vec
      #plot(S,b1vec) ###explore more
      #lines(S,Beta1(S),col="red")
      
      st<-(1*nbasis)+1
      end<- 2*nbasis 
      b2coef<-gamma3[-1][st:end]     
      b2_est<-function(t)
      {basisvec<-eval.basis(t,bbasis)
      val<-crossprod(t(basisvec),b2coef)
      as.numeric(val)
      }
      b2vec<-b2_est(S)
      b2estL[[iter]]<-b2vec
      #plot(S,b2vec) ###explore more
      #lines(S,Beta2(S),col="red")
      
      ####start ADMM########
      ###alpha update################
      st<-(2*nbasis)+1
      end<- st+ncol(GrandS)-1
      
      param<-gamma3[-1][st:end]
      options(digits.secs = 6)
      UGRIDsub<-seq(-8,8,l=100)
      TGRID<-S
      #thetaMATest<-outer(UGRID,TGRID,theta_b_est)
      
      theta_c_est<-function(uvec,tvec)
      {ui<-uvec
      bastval<-eval.basis(tvec,bbasisT)
      basUval<-eval.basis(ui,bbasisU)
      parammat<-matrix(param,nbasisU,nbasisT,byrow=TRUE)
      valmat<-basUval%*%parammat%*%t(bastval)
      valmat+gamma3[1]
      }
      thetaMATest2<-theta_c_est(UGRIDsub,TGRID)
      #library(fields)
      #image.plot(UGRIDsub,TGRID,thetaMATest2)
      #thetaMAT<-outer(UGRIDsub,TGRID,theta)
      
      #library(fields)
      #image.plot(UGRIDsub,TGRID,thetaMAT)
      #thetaloss[iter]<-mean((thetaMAT-thetaMATest2)^2)
      thetaloss[[iter]]<-thetaMATest2
      
      #UPDATE1
      galpha<-function(alpha)
      {uimatvec<-as.numeric(M%*%alpha)
      if(range(uimatvec)[1]>=dayrngU[1] & range(uimatvec)[2]<=dayrngU[2])
      {
        sitermmat<-theta_c_est(uimatvec,S)
        lossmatTEMP<-Ymat-sitermmat-X[,1]%*%t(b1vec)-X[,2]%*%t(b2vec)
        loss<-mean(lossmatTEMP^2)
        penloss<-loss+as.numeric(t(mu0)%*%(c0-alpha))+as.numeric(t(mu1)%*%(c1-alpha))+(rho/2)*sum((c0-alpha)^2)+(rho/2)*sum((c1-alpha)^2)
      }
      else{penloss=99999999}
      penloss
      }
      res3 <- optim(alpha_in,galpha, method = "BFGS",control=list(maxit=10000))
      #res3$par
      #res3$value
      alpha_in<-res3$par
      alphaL[[iter]]<-alpha_in
      ###UPDATE 2
      vec_to_proj<-alpha_in-(1/rho)*mu0
      proj_sphere_unipos<-function(v)
      {if(v[1]>=0)
      {denom<-sqrt(sum(v^2))
      val<-v/denom
      }
        if(v[1]<0)
        {v[1]=0
        denom<-sqrt(sum(v^2))
        val<-v/denom
        }
        val
      }
      
      c0<-proj_sphere_unipos(vec_to_proj)
      c0L[[iter]]<-c0
      ########C1####################################
      prox_vec<-alpha_in-(1/rho)*mu1  ##leave first cord unpen
      soft_mcp<-function(beta,lambda,gamma)
      {if(abs(beta)>lambda*gamma)
      {val<-beta}
        
        if(abs(beta)<=lambda*gamma)
        {
          if(beta>lambda)
          {val=beta-lambda}
          if(beta< -lambda)
          {val=beta+lambda}
          if(beta <= lambda & beta >= -lambda)
          {val=0}  
        }
        return(val)  
      }
      soft_mcp<-Vectorize(soft_mcp,vectorize.args = c("beta")) 
      c1=c(prox_vec[1],soft_mcp(prox_vec[-1],lambda,gamma))
      c1L[[iter]]<-c1
      ####update 3 : Update multipliers########################
      mu0=mu0+rho*(c0-alpha_in)
      mu1=mu1+rho*(c1-alpha_in)
      mu0L[[iter]]<-mu0
      mu1L[[iter]]<-mu1
      #print(iter)
      #print(c1)
      #print(sum(c0^2))
      #print(c0[1])
      c1<-normalize(c1)
      c0=c1
      alpha_in=c1
      if(iter>1 )
      {
        if(sqrt(sum((c1L[[iter]]-c1L[[(iter-1)]])^2))/sqrt(sum((c1L[[(iter-1)]])^2))<= tol & sqrt(sum((b1estL[[iter]]-b1estL[[(iter-1)]])^2))/sqrt(sum((b1estL[[(iter-1)]])^2))<= tol & sqrt(sum((b2estL[[iter]]-b2estL[[(iter-1)]])^2))/sqrt(sum((b2estL[[(iter-1)]])^2))<= tol & sqrt(sum((thetaloss[[iter]]-thetaloss[[(iter-1)]])^2))/sqrt(sum((thetaloss[[(iter-1)]])^2)+0.0000001) <=tol)
        {break}
      }
      ###iterate
    }
    #look at normalized c1 at the end
    #and c1[1]>0
    if(c1[1]<=0)
    {c1=-c1}
    if (sum(c1^2)>0){
      c1<-(c1)/(sqrt(sum((c1)^2)))}
    #bic
    bicLoss_alpha<-function(alpha)
    {uimatvec<-as.numeric(M%*%alpha)
    if(range(uimatvec)[1]>=dayrngU[1] & range(uimatvec)[2]<=dayrngU[2] & sum(alpha^2)>0)
    {
      sitermmat<-theta_c_est(uimatvec,S)
      lossmatTEMP<-Ymat-sitermmat-X[,1]%*%t(b1vec)-X[,2]%*%t(b2vec)
      loss<-mean(lossmatTEMP^2)
      penloss<-log(loss)+(log(n)/(n))*sum(alpha!=0)   ##n many curves
    }
    else{penloss=99999999}
    penloss
    }
    val<-bicLoss_alpha(c1)
    varsel<-which(c1!=0)
    addMATest<-thetaMATest2
    result<-list(varselected=varsel,bicval=val,alphaest=c1,b1est=b1vec,b2est=b2vec,param_surf=param,thetaest=thetaMATest2)
    return(result)}
  reslambda<-bicfunc(lambda)
  ##process into varselected lambda and coefficient functions#
  return(reslambda)
}


###cv function on lambda and final estimate#########
#@Ymat: n*m response on a grid
#@X: n*p1 covariates to adjust for 
#@M: n*p2 covariates for single index
#@UT: Grid of timepoints for Y(t)
#@alpha_in: Initial value of alpha
#@maxit: Maximum iteration for the iterative procedure
#@tol: Relative tolerance limit for covergence
#@cvl: length of the grid of lambda values for CV
FSIM.varsel.cv<-function(Ymat,X,M,UT,alpha_in,maxit=50,tol=0.001,cvl=50){
  lambdagrid<-seq(0.001,2,l=cvl)
  ##can use parLapply (in Windows) with parallel support to make this faster##
  resultcvL<-lapply(lambdagrid, function(lambda){FSIM.varsel(Ymat,X,M,UT,alpha_in,lambda,maxit=maxit,tol=tol)})
  bicvec<-c()
  for (l in 1: length(lambdagrid))
  {bicvec[l]<-resultcvL[[l]]$bicval}
  indminbic<-which.min(bicvec)[1]
  result<-resultcvL[[indminbic]]
  result$lambdasel<-lambdagrid[indminbic]
  return(result)
}
