1. Fsim_Selection.html shows illustration of the variable selection method in the paper.  

2. Fsim_Selection.Rmd file contains the R markdown code for the same.

3. Functions (source the source_FSIM.R file for loading all the following functions)

i) Function for choosing active covariate.
#@Ymat: n*m response on a grid
#@X: n*p1 covariates to adjust for, current implementation p1=2. 
#@M: n*p2 covariates for single index
Use: act.cov.index(Ymat,X,M) 
Value: Column index of active covariate in M.

ii) Function for choice of initial alpha.
#@Ymat: n*m response on a grid
#@X: n*p1 covariates to adjust for, current implementation p1=2. 
#@M: n*p2 covariates for single index
#@try: number of initial values to be tried
Use: Initial.alpha.choose(Ymat,X,M,try)
Value: Intitial value of alpha

iii) Function for variable selection method in FSIM for a fixed value of lambda.
#@Ymat: n*m response on a grid
#@X: n*p1 covariates to adjust for, current implementation p1=2. 
#@M: n*p2 covariates for single index
#@UT: Grid of timepoints for Y(t)
#@alpha_in: Initial value for alpha
#@lambda: Penalty parameter corresponding to MCP on alpha
#@maxit: Maximum iteration for the iterative procedure
#@tol: Relative tolerance limit for covergence
Use: FSIM.varsel(Ymat,X,M,UT,alpha_in,lambda,maxit,tol)
Value:
#$varselected: Selected columns of M (after permuting with active covariate) #main interest
#$bicval: BIC value at lambda
#$alphaest: Estimated alpha
#$b1est: Estimated \beta_1(t)
#$b2est: Estimated \beta_2(t)
#$thetaest: Estimated \theta(u,t) on a grid


iv) Function for variable selection method in FSIM using cross-validation on a lambda grid.
#@Ymat: n*m response on a grid
#@X: n*p1 covariates to adjust for, current implementation p1=2.  
#@M: n*p2 covariates for single index
#@UT: Grid of timepoints for Y(t)
#@alpha_in: Initial value of alpha
#@maxit: Maximum iteration for the iterative procedure
#@tol: Relative tolerance limit for covergence
#@cvl: length of the grid of lambda values for cross-validation using BIC function.
Use: FSIM.varsel.cv(Ymat,X,M,UT,alpha_in,maxit,tol,cvl)
Value:
#$varselected: Selected columns of M (after permuting with active covariate) #main interest
#$bicval: BIC value at optimal lambda
#$alphaest: Estimated alpha
#$b1est: Estimated \beta_1(t)
#$b2est: Estimated \beta_2(t)
#$thetaest: Estimated \theta(u,t) on a grid
#$lambdasel: Selected value of lambda producing smallest BIC



